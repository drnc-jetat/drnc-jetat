# drnc-jetat

JETAT sistemiyle hazırlanmış altılı ganyan kupon uygulaması. React + Tailwind + shadcn UI ile geliştirilmiştir.
