// pages/index.tsx

import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useState } from "react";

const stratejiKuponu = [
  {
    kosuNo: 1,
    adaylar: ["LORD OF WIND"],
  },
  {
    kosuNo: 2,
    adaylar: ["ALTIN KRAL", "KIR TUTKUSU", "YAMAN TAY"],
  },
  {
    kosuNo: 3,
    adaylar: ["YILDIRIM HAN"],
  },
  {
    kosuNo: 4,
    adaylar: ["KARA GÖZLÜM", "GECE RÜZGARI", "KIZIL FIRTINA"],
  },
  {
    kosuNo: 5,
    adaylar: ["TEK KILIÇ"],
  },
  {
    kosuNo: 6,
    adaylar: ["KAFKAS ŞİMŞEĞİ"],
  },
];

export default function AltiliKupon() {
  const kolonSayisi = stratejiKuponu.reduce((acc, kosu) => acc * kosu.adaylar.length, 1);
  const maliyet = kolonSayisi * 0.6;

  return (
    <div className="flex flex-col gap-4 p-4 max-w-screen-sm mx-auto">
      <h1 className="text-xl font-bold text-center">JETAT Stratejik Altılı Kupon</h1>
      {stratejiKuponu.map((kosu) => (
        <Card key={kosu.kosuNo} className="shadow-lg">
          <CardContent className="p-4">
            <h2 className="text-lg font-semibold">{kosu.kosuNo}. Koşu</h2>
            <p><strong>Adaylar:</strong> {kosu.adaylar.join(", ")}</p>
          </CardContent>
        </Card>
      ))}
      <div className="text-center font-semibold">
        Toplam Kolon Sayısı: {kolonSayisi} - Tahmini Maliyet: {maliyet.toFixed(2)} TL
      </div>
      <div className="text-sm text-center text-gray-600">
        Strateji Özeti: 4 koşu banko, 2 koşu sürpriz adaylarla genişletildi. Hedef: kontrollü riskle yüksek kazanç.
      </div>
    </div>
  );
}
